package com.genc.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.genc.entity.User;
import com.genc.exception.PasswordNotMatchException;
import com.genc.exception.UserNotFoundException;

@Service
public interface UserService {


	boolean signIn(User user) throws UserNotFoundException;

	boolean signOut(User user) throws UserNotFoundException;

	User changePassword(int userid, User user) throws UserNotFoundException, PasswordNotMatchException;
	
	List<User> getAllUsers();
	
	User getUserById(int userId);
	
	User getUserByEmail(String email);
	
	User createUser(User user);
 
}
