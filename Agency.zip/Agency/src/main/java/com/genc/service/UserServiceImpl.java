package com.genc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genc.Repository.UserRepository;
import com.genc.entity.User;
import com.genc.exception.PasswordNotMatchException;
import com.genc.exception.UserNotFoundException;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository uDao;


	@Override
	public boolean signIn(User user) throws UserNotFoundException {
		Boolean status= false;
//		Optional<User> resultUser= userRepository.findById(user.getUserId());
		Optional<User> resultBroker= Optional.of(uDao.findByEmail(user.getEmail()));
		if (resultBroker.isPresent()) {
			if((resultBroker.get().getPassword().equals(user.getPassword()))) 
			{
				status=true;

		} 
			else 
			
			throw new UserNotFoundException("User Not Found");
		}
		return status;
	}
	
	

	@Override
	public boolean  signOut(User user) throws UserNotFoundException {
		Boolean status=false;
		Optional<User> resultBroker=uDao.findById(user.getUserId());

		if (resultBroker.empty() != null) {
			throw new UserNotFoundException("User Not Found");
		}
		else if(resultBroker.get().getPassword().equals(user.getPassword())) {
			 status = true;
		}
		return status;
	}
	
	

	

	@Override
	public User changePassword(int userid, User user) throws UserNotFoundException, PasswordNotMatchException {

		Optional<User> resultUser=uDao.findById(user.getUserId());
		if(resultUser.isPresent()) {
				resultUser.get().setPassword(user.getPassword());
				return uDao.save(resultUser.get());
			
		}
		else
		{
			throw new UserNotFoundException("User Not Found");
		}	

}

	@Override
	public List<User> getAllUsers() {
		
		return uDao.findAll();
	}

	@Override
	public User getUserById(int userId) {
		return uDao.findById(userId).get();
	}

	@Override
	public User getUserByEmail(String email) {
		return uDao.findByEmail(email);
	}



	@Override
	public User createUser(User user) {
		return uDao.save(user);
	}
	

}