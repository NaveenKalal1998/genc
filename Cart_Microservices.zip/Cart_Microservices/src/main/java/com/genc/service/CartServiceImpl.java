package com.genc.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genc.Repository.CartRepository;
import com.genc.entity.Cart;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepository cDao;

	//get all properties in cart
	@Override
	public List<Cart> getAllPropertiesCart() {
		// TODO Auto-generated method stub
		return cDao.findAll();
	}

	//save each cart
	@Override
	public Cart saveToCartProperty(Cart cart) {
		// TODO Auto-generated method stub
		return cDao.save(cart);
	}

	@Override
	public List<Cart> getCartByCustId(int custId) {
		// TODO Auto-generated method stub
		return cDao.findByCustId(custId);
	}

	//get a cart by custId
	


	
//	@Override
//	public List<User> getAllUsers() {
//		
//		return uDao.findAll();
//	}
//
//	@Override
//	public User getUserById(int userId) {
//		return uDao.findById(userId).get();
//	}
//
//	@Override
//	public User createUser(User user) {
//		return uDao.save(user);
//	}
	

}