package com.genc.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.genc.entity.Cart;

@Service
public interface CartService {


	List<Cart> getAllPropertiesCart();
	
	Cart saveToCartProperty(Cart cart);
 
	List<Cart> getCartByCustId(int custId);
}
