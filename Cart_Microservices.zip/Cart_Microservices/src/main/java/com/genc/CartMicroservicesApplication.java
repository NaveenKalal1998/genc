package com.genc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartMicroservicesApplication.class, args);
	}

}
