import './App.css';
import Home from './components/Home';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import About from './components/About';
import Login from './components/Login';
import Contact from './components/Contact';
import Properties from './components/Properties';
import Developers from './components/Developers';
import SignIn from './components/SignIn';
import Search from './components/Search';
import CustomerListProp from './components/CustomerListProp';
import CustomerMyProp from './components/CustomerMyProp';
import CustomerUpdate from './components/CustomerUpdate';
import CustomerPage from './components/CustomerPage';
import BrokerPage from './components/BrokerPage';
import ChangeBrokerProfileHandler from './components/ChangeBrokerProfileHandler';
import CreatePropertyHandler from './components/CreatePropertyHandler';
import Search1 from './components/Search1';
import Logout from './components/Logout';
import ShowBrkoerProeprty from './components/ShowBrkoerProeprty';
import dummy from './components/dummy';
function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route path="/" exact component={Home}></Route>
          <Route path="/home" component={Home}></Route>
          <Route path="/about" component={About}></Route>
         
          <Route path="/properties" component={Properties}></Route>
          <Route path="/developers" component={Developers}></Route>
          <Route path="/contact" component={Contact}></Route>
          <Route path="/login" component={Login}></Route>
          <Route path="/signin" component={SignIn}></Route>
          <Route path="/search" component={Search}></Route>
          <Route path="/customerListProp" component={CustomerListProp}></Route>
          <Route path="/customerMyProp" component={CustomerMyProp}></Route>
          <Route path="/customerUpdate" component={CustomerUpdate}></Route>
          <Route path="/customerPage" component={CustomerPage}></Route>
          <Route path="/brokerPage" component={BrokerPage}></Route>
          {/* <Route path="/brokerPage/:id" component={BrokerPage}></Route> */}
          <Route path="/createPropertyHandler" component={CreatePropertyHandler}></Route>
          <Route path="/changeBrokerProfileHandler" component={ChangeBrokerProfileHandler}></Route>
          {/* <Route path="/changeBrokerProfileHandler/:id" component={ChangeBrokerProfileHandler}></Route> */}
           <Route path="/search1" component={Search1}></Route>
           <Route path="/logout" exact component={Logout}></Route>
            <Route path="/showBrkoerProeprty" component={ShowBrkoerProeprty}></Route>
          <Route path="/dummy" component={dummy}></Route>
        </Switch>
      </Router>
      
    </div>
  );
}

export default App;
