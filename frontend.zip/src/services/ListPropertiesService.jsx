import axios from 'axios'
const url = "http://localhost:8093/api/v1/property";

class ListPropertiesService{
  
    get()
    {
        return axios.get(url);
    }
}
export default new ListPropertiesService();