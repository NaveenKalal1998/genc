
import axios from 'axios';
const url="  http://localhost:8092/api/v1/users";
 class signUpservice  {

  getUser()
  {
    return axios.get(url);
  }

  createUser(user){
    return axios.post(url,user);
  }
  
}

export default new signUpservice()