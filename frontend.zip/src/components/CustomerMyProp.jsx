import React, { Component } from 'react'
import Header from './Header';
import CustomerPage from './CustomerPage';
import Footer from './Footer';
class CustomerMyProp extends Component {
  render() {
    return (
<div>
          <Header/><br/><br/><br/>
          <CustomerPage/><br/><br/>
       <h1>My Properties</h1>
        <br/><br/>
        <Footer/>
      </div>
    )
  }
}
export default CustomerMyProp;