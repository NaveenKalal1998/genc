import React, { Component } from 'react'
import CustomerPage from './CustomerPage'
import Footer from './Footer'
import Header from './Header'

class Properties extends Component {
  render() {
    return (
      <div>
        <Header/><br/><br/><br/>
        {/* <CustomerPage /><br/> */}
        <p><a href='/customerPage'>CustomerPage</a></p>
        <p><a href='/brokerPage'>BrokerPage</a></p>
        <Footer/>
      </div>
      
    )
  }
}
export default Properties