import React, { Component } from 'react'
import Header from './Header'
import { Card } from 'reactstrap'
import axios from 'axios'
import SigninService from '../services/SigninService'
import Role from '../services/Role'

class SignIn extends Component {
  constructor(props) {
    super(props)

    this.state = {
        password:'',
      email:''
    }
    this.changeSigninHandler = this.changeSigninHandler.bind(this);
    this.changeSignUpHandler = this.changeSignUpHandler.bind(this);
    this.handleEmail = this.handleEmail.bind(this);
    this.handlePassword = this.handlePassword.bind(this);
    
  }
  
  changeSignUpHandler = () => {
    this.props.history.push("/login")
  }

  handleEmail = e =>{
    this.setState({
      email: e.target.value
    })
  }
  handlePassword =e =>{
    this.setState({
     password:e.target.value
    })
  }
  changeSigninHandler = (e) =>
  {
    e.preventDefault();
    let user={password:this.state.password,email:this.state.email};
    console.log('user => ' + JSON.stringify(user));
      SigninService.loginUser(user).then(res =>
        {
          console.log(res.data)
          if(res.data == true)
          {
            sessionStorage.setItem('email',user.email);
            console.log(this.state.email)
              Role.getUserByEmail(this.state.email).then(res1 =>
                {
                  sessionStorage.setItem('userId',res1.data.userId);
                  console.log('user => ' + JSON.stringify(res1.data))
                  console.log(res1.data.role)
                  let userId = res1.data.userId;
                  if(res1.data.role=='broker')
                  {
                    //this.props.history.push("/brokerPage/${userId}")
                    this.props.history.push("/brokerPage")
                  }
                  else{
                    this.props.history.push("/customerPage")
                  }
                }
                )
                
          }
          else
          {
            this.props.history.push("/signin")
          }
         
        });
    // console.warn(this.state.name,this.state.email,this.state.password,this.state.mobile,this.state.role,this.state.city)
   
  }
  render() {
    return (
      <div>
        <Header /><br /><br /><br /><br />
        <div class='card'>
          <div class='container'>
            <div class="row align-items-center">
              <div class="col">
                <h3>Sign in</h3>

                <form onSubmit={this.formHandler} >
                <div>
                  <input name="email" type='email' placeholder='Email Id' value={this.state.email} style={{ marginLeft: '.5rem' }} onChange={this.handleEmail} required /><br />
                  <br />
                </div>
                <div>
                  <input name="password" type='password' placeholder='password' value={this.state.password} style={{marginLeft:'.5rem'}} onChange={this.handlePassword} required/><br/>

                  <br />
                </div>
                <button class='btn btn-success' onClick={this.changeSigninHandler}>SIGNIN</button>
                </form>
              </div>
              


              <div class="col" style={{backgroundColor:"green"}}>
                <h3>Hello, Friend!</h3>
                <div>
                  <h6 style={{color:"white"}}>Enter your personal details and start journey with us</h6><br/>
                </div>
                <button class='btn btn-success' onClick={this.changeSignUpHandler}>SIGN UP</button>
              </div>
            </div>
          </div>       
        </div>

      </div>
    )
  }
}
export default SignIn
