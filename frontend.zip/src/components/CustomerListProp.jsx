import React, { Component } from 'react';
import { Card } from 'reactstrap';
import property_search from "../images/property_search.png";
import CustomerPage from './CustomerPage';
import Header from './Header';
import SearchPropertyByCriteria from '../services/SearchPropertyByCriteria';
import axios from 'axios'
import Search1 from './Search1';
import ListPropertiesService from '../services/ListPropertiesService';
class CustomerListProp extends Component {

  constructor(props) {
    super(props)

    this.state = {
      config: 'flat',
      offer: 'sell',
      city: 'Ahmedabad',
      minCost: '',
      maxCost: '',

      property: []
    }
    this.changeHandlerSerach = this.changeHandlerSerach.bind(this)
  }
  

  changeHandlerSerach = (e) => {
    e.preventDefault();
    
    ListPropertiesService.get().then(res => {
      this.setState({ property: res.data });

      console.log(res.data)
      console.log('properties => ' + JSON.stringify(res.data))
      //this.props.history.push("/signin");
      //console.log(res.data.map(a => a.city))
      //res.data.map(a =><h1> a.city</h1>)

     //this.props.history.push("/search1");
    });
    // console.warn(this.state.name,this.state.email,this.state.password,this.state.mobile,this.state.role,this.state.city)

  }

 
  render() 
  {
    return (
      <div>
        <Header /><br /><br /><br />
        <CustomerPage />
        <div class='card'>
        <button class='btn btn-success' onClick={this.changeHandlerSerach} >List of Properties</button>
                  
            <div className="row">
                <table className="table table-striped table-bordered">

                  <thead>
                    <tr>
                      <th> Configuration</th>
                      <th> OfferType</th>
                      <th> OfferCost</th>
                      <th> Area Sqft</th>
                      <th> City</th>
                      <th> Address</th>
                      <th> Street</th>
                      <th> Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {
                      this.state.property.map(
                        pr =>
                          <tr key={pr.propId}>
                            <td> {pr.configuration} </td>
                            <td> {pr.offerType}</td>
                            <td> {pr.offerCost}</td>
                            <td> {pr.areaSqft}</td>
                            <td> {pr.city}</td>
                            <td> {pr.address}</td>
                            <td> {pr.street}</td>
                            <td> {pr.status}</td>
                          </tr>
                      )}
                  </tbody>
                </table>
                </div>
          </div>
        </div>
        )
  }
}
        
        export default CustomerListProp;