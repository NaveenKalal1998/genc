import React, { Component } from 'react'
import Header from './Header'
import Footer from './Footer'
import boy from '../images/boy.jpg'
import girl from '../images/girl.jpg'
class Developers extends Component {
  render() {
    return (
      <div>
        <Header/>
        <br/>
        <br/>
        <br/>
        <div class='container'>
          <br/>
          <br/>
          {/* add the developers pic  */}
          <div>     
                 <h1>Our Amazing Developers</h1>
                 <p></p>
                 <p></p>
          </div>
          <div class='container'>
                    <div class="row align-items-center">
                         
                        <div class="col">
                            <img src={girl} class="img-thumbnail" alt="..." ></img>
                          
                            <h><b>Name:- Kruthika K   </b></h><br></br>
                           <h><b> Contact no:- 8310671441 </b></h>
                           <h><b> Email Id :- kruthika01@gmail.com </b></h>
                           
                           
                         
                        
                        </div>
                        <div class="col">
                            <img src={boy} class="img-thumbnail" alt="..." >
                            

                           </img>
                           <h><b>Name:- K Naveen Kumar </b></h><br></br>
                           <h><b> Contact no:- 8310111727 </b> </h>
                           <h><b> Email Id :- Knaveen@gmail.com </b></h>
                           

                           
                        </div> 
                        <div class="col">
                            <img src={girl} class="img-thumbnail" alt="..." ></img>
                            <h><b>Name:- Shravani Umale  </b></h><br></br>
                           <h><b> Contact no:- 9168735026 </b> </h>
                           <h><b> Email Id :- Shrey@gmail.com </b></h>
                         
                        </div>
                        <div class="col">
                            <img src={boy} class="img-thumbnail" alt="..." ></img>
                            <h><b>Name:- Bhargav Reddy  </b></h><br></br>
                           <h><b> Contact no:- 9182171383 </b> </h>
                           <h><b> Email Id :- reddy1@gmail.com </b></h>
                            
                        </div>
                        <div class="col">
                            <img src={girl} class="img-thumbnail" alt="..." ></img>
                            <h><b>Name:- Soundarya TS </b></h><br></br>
                           <h><b> Contact no:- 9344262546</b> </h>
                           <h><b> Email Id :- soundarya@gmail.com </b></h>
                         
                        </div>
                    </div>
                </div>
          
        </div>
        <Footer />
      </div>
      
    )
  }
}

export default Developers
