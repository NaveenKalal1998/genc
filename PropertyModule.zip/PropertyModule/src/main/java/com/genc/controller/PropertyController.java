package com.genc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genc.entity.Property;
import com.genc.exception.PropertyNotFoundException;
import com.genc.exception.ResourceNotFoundException;
import com.genc.pojo.PropertyCriteria;
import com.genc.repository.PropertyRepository;
import com.genc.service.IPropertyService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class PropertyController 
{
  @Autowired
 private PropertyRepository propertyRepository;
   
  //get all property
  @GetMapping("/property")
  public List<Property> getAllProperty()
  {
	  return propertyRepository.findAll();
  }
  
  
  //create product
  @PostMapping("/property")
  public Property createProperty(@RequestBody Property property)
  {
	  return propertyRepository.save(property);
  }
  
  //get product by id rest api
  @GetMapping("/property/{id}")
  public ResponseEntity<Property> getPropertyById(@PathVariable Integer id) 
  {
	  Property property=propertyRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("product does not exist with a id "+id));
	  return ResponseEntity.ok(property);
  }
  
//  //update product rest api
//  @PutMapping("/products/{id}")
//  public ResponseEntity<Product> updateProduct(@PathVariable Integer id,@RequestBody Product productDetails) 
//  {
//	  Product product=productRepository.findById(id).
//			  orElseThrow(()->new ResourceNotFoundException("product does not exist with a id "+id));
//	  product.setName(productDetails.getName());
//	  product.setPassword(productDetails.getPassword());
//	  product.setMobile(productDetails.getMobile());
//	  product.setEmail(productDetails.getEmail());
//	  product.setCity(productDetails.getCity());
//	  product.setRole(productDetails.getCity());
//	  
//	  User updateUser=userRepository.save(user);
//	  return ResponseEntity.ok(updateUser);
//  }
  

	@Autowired
	IPropertyService propertyService;
	
	//add the property
	@PostMapping(value = "/add")
	public Property addProperty(@RequestBody Property property) {
		return propertyService.addProperty(property);
	}
	
	
	//update the property
	@PutMapping(value = "/update")
	public Property updatePropertyData(@RequestBody Property property) throws PropertyNotFoundException {
		try {
			propertyService.viewProperty(property.getPropId());
		}
		catch(Exception e) {
			throw new PropertyNotFoundException("The property does not exists");
		}
		return propertyService.editProperty(property);

	}
	
	
//	@DeleteMapping("/remove/{propId}")
//	public Property deleteProperty(@PathVariable int propId) throws PropertyNotFoundException {
//		Property p = null;
//		try {
//			p = propertyService.removeProperty(propId);
//		} catch (Exception e) {
//			throw new PropertyNotFoundException("The entered propId is not found! Enter a valid propId to delete.");
//		}
//		return p;
//	}

	//get property by prop_id
	@GetMapping("/id/{propId}")
	public Property findPropertyById(@PathVariable int propId) throws PropertyNotFoundException {
		Property p = null;
		try {
			p = propertyService.viewProperty(propId);
		} catch (Exception e) {
			throw new PropertyNotFoundException("The entered propId is not found! Enter a valid propId to find.");
		}
		return p;
	}

	//get all list of properties
	@GetMapping("/all")
	public List<Property> printAllProperties() {
		return propertyService.listAllProperties();
	}

	//get all properties by criteria
	@PostMapping("/criteria")
	public List<Property> listPropertyByCriteria(@RequestBody PropertyCriteria criteria) throws PropertyNotFoundException {
		System.out.println(criteria.getMinCost());
		List<Property> p= propertyService.ListPropertyByCriteria(criteria);
		if(p.isEmpty())
			throw new PropertyNotFoundException("No Property found with given criteria");
		return p;
	}
}
