package com.genc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genc.Repository.DevelopersRepository;

import com.genc.entity.Developers;


@Service
public class DevelopersImpl implements DevelopersService {

	@Autowired
	private DevelopersRepository dDao;


	

	@Override
	public List<Developers> getAllDevelopers() {
		
		return dDao.findAll();
	}

	@Override
	public Developers getDevelopersById(int devId) {
		return dDao.findById(devId).get();
	}

	@Override
	public Developers createDevelopers(Developers developers) {
		// TODO Auto-generated method stub
		return dDao.save(developers);
	}

	
	

}