package com.genc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genc.entity.Developers;
import com.genc.service.DevelopersService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class DevelopersController 
{
//  @Autowired
// private UserRepository userRepository;
//   
//  //get all users
//  @GetMapping("/users")
//  public List<User> getAllUser()
//  {
//	  return userRepository.findAll();
//  }
//  
//  
//  //create user
//  @PostMapping("/users")
//  public User createUser(@RequestBody User user)
//  {
//	  return userRepository.save(user);
//  }
//  
//  //get user by id rest api
//  @GetMapping("/users/{id}")
//  public ResponseEntity<User> getUserById(@PathVariable Integer id) 
//  {
//	  User user=userRepository.findById(id).
//			  orElseThrow(()->new ResourceNotFoundException("user does not exixt with a id "+id));
//	  return ResponseEntity.ok(user);
//  }
//  
//  //update user rest api
//  @PutMapping("/users/{id}")
//  public ResponseEntity<User> updateUser(@PathVariable Integer id,@RequestBody User userDetails) 
//  {
//	  User user=userRepository.findById(id).
//			  orElseThrow(()->new ResourceNotFoundException("user does not exixt with a id "+id));
//	  user.setName(userDetails.getName());
//	  user.setPassword(userDetails.getPassword());
//	  user.setMobile(userDetails.getMobile());
//	  user.setEmail(userDetails.getEmail());
//	  user.setCity(userDetails.getCity());
//	  user.setRole(userDetails.getCity());
//	  
//	  User updateUser=userRepository.save(user);
//	  return ResponseEntity.ok(updateUser);
//  }
  

	@Autowired
	private DevelopersService dService;
	
	@GetMapping("/dev")
	public List<Developers> getAllUsers(){
		return dService.getAllDevelopers();
	}
	
	@GetMapping("/id/{userId}")
	public Developers getUserById(@PathVariable int userId) {
		return dService.getDevelopersById(userId);
	}
	@PostMapping("/developers")
	  public Developers createUser(@RequestBody Developers dev)
	  {
		  return dService.createDevelopers(dev);
	  }
	  
	
  
}
