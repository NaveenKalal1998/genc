package com.genc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevelopersModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevelopersModuleApplication.class, args);
	}

}
