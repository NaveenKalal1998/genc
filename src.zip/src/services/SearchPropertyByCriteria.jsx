
import axios from 'axios';
const url="  http://localhost:8093/api/v1/criteria";
 class SearchPropertyByCriteria  {

  searchProperty(criteria){
    return axios.post(url,criteria);
  }
  
}

export default new SearchPropertyByCriteria()