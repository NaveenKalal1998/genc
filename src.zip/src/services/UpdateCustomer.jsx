
import axios from 'axios';
const url="  http://localhost:8092/api/v1/users";

const url1 = "http://localhost:8092/api/v1/email";
 class UpdateCustomer  {

  getUser()
  {
    return axios.get(url);
  }

  getUserByEmail(email)
  {
    return axios.get(url1 + '/' + email)
  }

  updateUser(user, userId){
    return axios.put(url + '/' + userId, user);
  }
  
}

export default new UpdateCustomer()