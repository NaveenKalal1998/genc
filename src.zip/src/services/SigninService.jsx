
import axios from 'axios';
const url="  http://localhost:8092/api/v1/login";
 class SigninService  {

  getUser()
  {
    return axios.get(url);
  }

  loginUser(user){
    return axios.post(url,user);
  }
  
}

export default new SigninService()