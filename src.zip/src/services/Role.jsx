import axios from 'axios';
const url="  http://localhost:8092/api/v1/email";
 class Role  {

  

  getUserByEmail(email){
    return axios.get(url + '/' + email);
  }
  
}

export default new Role()