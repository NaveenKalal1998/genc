import axios from "axios";
const url="http://localhost:8093/api/v1/property";
class CreatePropertService  {

    getProperty()
    {
      return axios.get(url);
    }
  
    createProperty(property){
      return axios.post(url,property);
    }
    
  }
  
  export default new CreatePropertService()
