import React, { Component } from 'react'
import Footer from './Footer';
import Header from './Header';
import brokerPage from "../images/brokerPage.jpg"

 class BrokerPage extends Component {
     constructor(props) {
       super(props)
     
       this.state = {
          
       }
       this.changeCreatePropertyHandler=this.changeCreatePropertyHandler.bind(this)
       this.changeBrokerProfileHandler=this.changeBrokerProfileHandler.bind(this)
     }
     changeCreatePropertyHandler = () =>
     {
        this.props.history.push("/createPropertyHandler")
     }
     changeBrokerProfileHandler = () =>
     {
        this.props.history.push("/changeBrokerProfileHandler")
     }
  render() {
    return (
      <div>
        <Header/><br/><br/><br/>
        <h1>Broker Page</h1>
        <br/><br/>
         <div>
             <img src={brokerPage}  height="600px"/>
         </div>
         <br/>
         <br/>
         
        <button class='btn btn-info' onClick={this.changeCreatePropertyHandler}>Create Property</button>
        <button class="btn btn-dark" onClick={this.changeBrokerProfileHandler}> My Profile</button>
         

      </div>
    )
  }
}
export default BrokerPage;