import React, { Component } from 'react'
import ListPropertiesService from '../services/ListPropertiesService';
import CustomerPage from './CustomerPage';
import Footer from './Footer';
import Header from './Header';

 class CustomerListProp extends Component {
   constructor(props) {
     super(props)
   
     this.state = {
        properties:[]
        
     }
   }
   
   componentDidMount()
   {
      ListPropertiesService.getProperties().then((res) => {
        this.setState({properties: res.data})
      })
   }

  render() {
    return (
      <div>
          <Header/><br/><br/><br/>
          <CustomerPage/><br/><br/>
       <h1> Properties Based On Criteria</h1>
      
        <br/><br/>
       <div className='row'>
         <table className='table table-striped table-bordered'>
           <thead>
             <tr>
               <td>Id</td>
               <td>OfferType</td>
               <td>Address</td>
               <td>Area in sqft</td>
               <td>City</td>
               <td>Configuration</td>
             </tr>
           </thead>
          <tbody>
            {
              this.state.properties.map(
                pro => {
                  <tr key={pro.propId}>
                  <td>{pro.propId}</td>
                  <td>{this.props.offerType}</td>
                  <td>{this.props.address}</td>
                  <td>{this.props.areaSqft}</td>
                  <td>{this.props.city}</td>
                  <td>{this.props.configuration}</td>
                </tr>
                }
               
              )
            }
          </tbody>
         </table>
       </div>
        <br/><br/>
        <Footer/>
      </div>
    )
  }
}
export default CustomerListProp;