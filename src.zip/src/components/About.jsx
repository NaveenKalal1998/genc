import React, { Component } from 'react'
import Footer from './Footer'
import Header from './Header'
import about1 from '../images/about1.jpg'
import EstateLogo from '../images/EstateLogo.png'

class About extends Component {
    render() {
        return (
            <div>
                <Header />
                <br />
                <br />
                <br />
                <div class='container'>
                    <div class='row'>
                        <h1>We Help You Find Your Perfect Home</h1>
                        <p><a href='#'>Home</a>/About</p>
                    </div>
                    <img src={about1} class="img-fluid" alt="..." ></img>

                    <div class='row'>
                        Our Believe<br/><br/>
                        We believe real estate is more than just building the proverbial four walls, it's about "Building a Better Life". This is the ideology with which we at EstateAgency have delivered the world's finest developments that have become some of the most iconic addresses of our customers.
                        <br/><br/>
                        Brokers can add, update and delete properties after signing up as broker.
                        Customer can see the list of properties available for buying, selling & renting.
                        Customer can buy/rent the properties after searching based of his preferences.
                        Once the customer bought/rented the property, it is no longer be available for others.
                        Customer can see the properties he bought/rented in his dashboard
                    </div>
                </div>
                <Footer />
            </div>
        )
    }
}

export default About