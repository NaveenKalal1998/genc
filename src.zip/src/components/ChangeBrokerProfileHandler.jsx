import React, { Component } from 'react'
import { Card } from 'reactstrap';
import CustomerPage from './CustomerPage';
import Header from './Header';
import customerUpdate from "../images/customerUpdate.png"
class ChangeBrokerProfileHandler extends Component {
  render() {
    return (
      <div>
        <div>
                <Header /><br /><br /><br />
                <CustomerPage />
                <div class='card'>
                    <div class='container'>
                        <div class="row align-items-center">
                            <img src={customerUpdate} width="300px" height="400px"></img>
                        </div>
                        <h1>Update Your Profile</h1>
                        <form>
                            <div class="container text-center">
                                <div>
                                    <label for='name'>Name</label>
                                    <input type='name' placeholder='Enter Name' style={{ marginLeft: '.5rem' }} required /><br />
                                    <br />

                                </div>
                                <div>
                                    <label for='email'>Email-Id</label>
                                    <input type='email' placeholder='Enter Email-id' style={{ marginLeft: '.5rem' }} required /><br />
                                    <br />
                                </div>
                                <div>
                                    <label for='city'>Mobile</label>
                                    <input type='mobile' placeholder='mobile' style={{ marginLeft: '.5rem' }} required /><br />
                                    <br />
                                </div>
                                <div>
                    <label for='city'>City</label>
                    <select name='city' id='city' style={{ marginLeft: '.5rem' }}>
                      <option value='ahmedabad'>Ahmedabad</option>
                      <option value='bengaluru'>Bengaluru</option>
                      <option value='Bhopal'>Bhopal</option>
                      <option value='chennai'>Chennai</option>
                      <option value='delhi'>Delhi</option>
                      <option value='guwahati'>Guwahati</option>
                      <option value='hyderabad'>Hyderabad</option>
                      <option value='jaipur'>Jaipur</option>

                      <option value='kanpur'>Kanpur</option>
                      <option value='kochi'>Kochi</option>
                      <option value='kolkata'>Kolkata</option>
                      <option value='lucknow'>Lucknow</option>
                      <option value='mumbai'>Mumbai</option>
                      <option value='nagpur'>Nagpur</option>
                      <option value='noida'>Noida</option>
                      <option value='patna'>Patna</option>
                      <option value='pune'>Pune</option>
                      <option value='vizag'>Vizag</option>
                    </select><br />
                    <br />
                  </div>
                                <div>
                                    <label for='password'>Password</label>
                                    <input type='password' placeholder='password' style={{ marginLeft: '.5rem' }} required /><br />
                                    <br />
                                </div>
                                <div>
                                    <label for='password'>Re-enter your Password</label>
                                    <input type='password' placeholder='password' style={{ marginLeft: '.5rem' }} required /><br />
                                    <br />
                                </div>
                              
                                <br />
                                <button class='btn btn-success' >UPDATE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
      </div>
    )
  }
}
export default ChangeBrokerProfileHandler