import React, { Component } from 'react'
import Header from './Header'
import login from "../images/login.png"
import signUpservice from '../services/signUpservice'
import axios from 'axios'
class Login extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
      password:'',
      name: '',
      mobile: '',
      email:'',
      city:'',
      role:'customer'  
    }
    this.changeSignUpHandler=this.changeSignUpHandler.bind(this)
    this.loginHandler=this.loginHandler.bind(this)
    this.handleName=this.handleName.bind(this)
    this.handleEmail=this.handleEmail.bind(this)
    this.handleMobile=this.handleMobile.bind(this)
    this.handlePassword=this.handlePassword.bind(this)
    this.handleRole=this.handleRole.bind(this)
    this.handleCity=this.handleCity.bind(this)
  }
  changeSignUpHandler = (e) =>
  {
    e.preventDefault();
    let user={password:this.state.password,name:this.state.name,mobile:this.state.mobile,email:this.state.email,city:this.state.city,role:this.state.role};
    console.log('user => ' + JSON.stringify(user));
      signUpservice.createUser(user).then(res =>
        {
          this.props.history.push("/signin");
        });
    // console.warn(this.state.name,this.state.email,this.state.password,this.state.mobile,this.state.role,this.state.city)
   
  }
  handleName = e =>{
    this.setState({
      name: e.target.value
    });
  }
  handleEmail = e =>{
    this.setState({
      email: e.target.value
    })
  }
  handleMobile =e =>{
    this.setState({
      mobile:e.target.value
    })
  }
  handlePassword =e =>{
    this.setState({
     password:e.target.value
    })
  }
  handleRole= e =>{
    this.setState({
      role:e.target.value
    })
  }
  handleCity =e =>{
    this.setState({
      city:e.target.value
    })
  }
  loginHandler = (e) =>
  {
    e.preventDefault();
     const u={
      name:this.state.name,
      email:this.state.email,
      mobile:this.state.mobile,
      password:this.state.password,
      role:this.state.role,
      city:this.state.city
    };
   axios.post(' http://localhost:8085/real-estate-broker-application/user/login',{u}).then(res =>{
     console.log(res);
     console.log(res.data);
   })
   fetch('http://localhost:8085/real-estate-broker-application/user/login', {
    method: 'post',
    headers: { 'Content-Type': 'application/json' },
    body:JSON.stringify({ data :this.u })
   });
  }
  

  render() {
    return (
      <div>
        <Header/><br/><br/><br/><br/><br/>
        <div>

          <div>
            <img src={login} width="500px" height="500px"></img>
          </div>
          <h3>Create an Account</h3>
          <form onSubmit={this.loginHandler} >
          <div class="container text-center">
            <div>
            <label for='name'>Name</label>
            <input  name="name" type='name' placeholder='Enter Name' value={this.state.name} style={{marginLeft:'.5rem'}} onChange={this.handleName} required/><br/>
            <br/>
            
            </div>
            <div>
            <label for='email'>Email-Id</label>
            <input  name="email" type='email' placeholder='Enter Email-id' value={this.state.email} style={{marginLeft:'.5rem'}} onChange={this.handleEmail} required/><br/>
            <br/>
            </div>
            <div>
            <label for='password'>Password</label>
            <input name="password" type='password' placeholder='password' value={this.state.password} style={{marginLeft:'.5rem'}} onChange={this.handlePassword} required/><br/>
            <br/>
            </div>
            <div>
            <label for='mobile'>Mobile</label>
            <input name="mobile" type='mobile' placeholder='mobile' value={this.state.mobile} style={{marginLeft:'.5rem'}} onChange={this.handleMobile} required/><br/>
            <br/>
            <div>
                    <label for='city'>City</label>
                    <select name='city' id='city' value={this.state.city} style={{ marginLeft: '.5rem' }} onChange={this.handleCity}>
                      <option value='ahmedabad'>Ahmedabad</option>
                      <option value='bengaluru'>Bengaluru</option>
                      <option value='Bhopal'>Bhopal</option>
                      <option value='chennai'>Chennai</option>
                      <option value='delhi'>Delhi</option>
                      <option value='guwahati'>Guwahati</option>
                      <option value='hyderabad'>Hyderabad</option>
                      <option value='jaipur'>Jaipur</option>

                      <option value='kanpur'>Kanpur</option>
                      <option value='kochi'>Kochi</option>
                      <option value='kolkata'>Kolkata</option>
                      <option value='lucknow'>Lucknow</option>
                      <option value='mumbai'>Mumbai</option>
                      <option value='nagpur'>Nagpur</option>
                      <option value='noida'>Noida</option>
                      <option value='patna'>Patna</option>
                      <option value='pune'>Pune</option>
                      <option value='vizag'>Vizag</option>
                    </select><br />
                    <br />
                  </div>
            <label for="role"> Choose a role</label>
            <select name='role' id='role' value={this.state.role} style={{marginLeft:'.5rem'}} onChange={this.handleRole} >
             <option value='customer'>Customer</option>
             <option value='broker'>Broker</option>
            </select><br/>
            </div>
            <br/>
            <button class='btn btn-success' onClick={this.changeSignUpHandler}>SignUp</button>
          </div>
          </form>
        </div>
        </div>
    )
  }
}
export default Login