import React, { Component } from 'react'
import Footer from './Footer'
import Header from './Header'
import dev1 from '../images/dev1.jpg'
class Developers extends Component {
  render() {
    return (
      <div>
        <Header/>
        <br/>
        <br/>
        <br/>
        <div class='container'>
          <br/>
          <br/>
          {/* add the developers pic  */}
          <div>     
                 <h1>Our Amazing Developers</h1>
                 
          </div>
          <div class='container'>
                    <div class="row align-items-center">
                        <div class="col">
                            <img src={dev1} class="img-thumbnail" alt="..." >

                            </img>

                            
                        </div>
                        <div class="col">
                            <img src={dev1} class="img-thumbnail" alt="..." ></img>
                         
                        </div>
                        <div class="col">
                            <img src={dev1} class="img-thumbnail" alt="..." ></img>
                            
                        </div>
                    </div>
                </div>
          
        </div>
        
        <Footer/>
      </div>
    )
  }
}

export default Developers
