import React, { Component } from 'react'

class dummy extends Component {

    constructor(props) {
        super(props)

        this.state = {
            users: []
        }
    }

    componentDidMount(){
        signUpservice.getUser().then((res) => {
            this.setState({users: res.data});
        });
    }

    render() {
        return (
            <div>
                <table>
                    <thead>hi</thead>
                    <tbody>
                        {
                            this.state.users.map(
                                user => 
                                <tr key = {user.userId}>
                                    <td> {user.name} </td>
                                    <td> {user.password} </td>
                                    <td> {user.mobile} </td>
                                </tr>
            )
                        }
                    </tbody>
                </table>

            </div>
        )
    }
}
export default dummy;