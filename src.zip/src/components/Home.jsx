import React, { Component } from 'react'
import Footer from './Footer'
import Header from './Header'
import EstateAgency1 from '../images/EstateAgency1.gif'
import sell from '../images/sell.png'
import rent from '../images/rent.png'
import buy from '../images/buy.png'
import Developers from './Developers'

class Home extends Component {
    render() {
        return (
            <div className='container'>
                <Header />

                {/* Services */}
                <img src={EstateAgency1} class="img-fluid" alt="..." ></img>
                <div class="text-start">
                    <h1>Our Services</h1>
                </div>
                <div class='container'>
                    <div class="row align-items-center">
                        <div class="col">
                            <img src={sell} class="img-thumbnail" alt="..." />
                            <p class="text-start">If you are a broker & selling a house, EstateAgency is where you should be. When you open our site, signup as a broker option to start with your property listings.</p>
                        </div>
                        <div class="col">
                            <img src={rent} class="img-thumbnail" alt="..." />
                            <p class="text-start">Thinking to Rent?
                                Find your perfect property from our property listings & save those extra bucks now.</p>
                        </div>
                        <div class="col">
                            <img src={buy} class="img-thumbnail" alt="..." />
                            <p class="text-start">Be it a plot, shop or a residential property, we give you variety of options, in terms of housing projects, societies and locations to buy.</p>
                        </div>
                    </div>
                </div>

                {/* Developers */}
                <Developers/>

                <Footer />
            </div>
        )
    }
}

export default Home