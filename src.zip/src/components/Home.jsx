import React, { Component } from 'react'
import Footer from './Footer'
import Header from './Header'
import EstateAgency1 from '../images/EstateAgency1.gif'
import sell from '../images/sell.png'
import rent from '../images/rent.png'
import buy from '../images/buy.png'
import Developers from './Developers'

class Home extends Component {
    render() {
        return (
            <div className='container'>
                <Header />

                {/* Services */}
                <img src={EstateAgency1} class="img-fluid" alt="..." ></img>
                <div class="text-start">
                    <h1>Our Services</h1>
                </div>
                <div class='container'>
                    <div class="row align-items-center">
                        <div class="col">
                            <img src={sell} class="img-thumbnail" alt="..." />
                            <p class="text-start"><i>If you are a broker & selling a house, EstateAgency is where you should be. When you open our site, signup as a broker option to start with your property listings.</i></p>
                        </div>
                        <div class="col">
                            <img src={rent} class="img-thumbnail" alt="..." />
                            <p class="text-start"><i>Thinking to Rent?
                                Find your perfect property from our property listings & save those extra bucks now.</i></p>
                        </div>
                        <div class="col">
                            <img src={buy} class="img-thumbnail" alt="..." />
                            <p class="text-start"><i>Be it a plot, shop or a residential property, we give you variety of options, in terms of housing projects, societies and locations to buy.</i></p>
                        </div>
                    </div>
                </div>
                <div>
                <link rel="stylesheet" href="/css/video-react.css" />
                
                <video width="750" height="500" controls >
                <source src="C:\Users\2101713\Downloads\genc-main\src\Videos\RE.mp4" type="video/mp4"/>
               </video> 
        
      </div>
                {/* Developers */}
                {/*<Developers/> */}

                <Footer />
            </div>
        )
    }
}

export default Home