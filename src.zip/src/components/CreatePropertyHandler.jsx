import React, { Component } from 'react'
import forms from "../images/forms.png"
import { Card } from 'reactstrap';
import CreatePropertyService from '../services/CreatePropertyService';
import axios from 'axios'
class CreatePropertyHandler extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
        config: 'flat',
        offer: 'sell',
        offerCost:'',
        area:'',
        city: 'Ahmedabad',
        address:'',
        street:'',
        status:'',
        statusBit:''
      }
      this.changeRegisterHandle=this.changeRegisterHandle.bind(this)
      this.handleConfig=this.handleConfig.bind(this)
      this.handleOffer=this.handleOffer.bind(this)
      this.handleOfferCost=this.handleOfferCost.bind(this)
      this.handleArea=this.handleArea.bind(this)
      this.handleCity=this.handleCity.bind(this)
      this.handleAddress=this.handleAddress.bind(this)
      this.handleStreet=this.handleStreet.bind(this)
      this.handleStatus=this.handleStatus.bind(this)
    }
    changeRegisterHandle = (e) =>
    {
        e.preventDefault();
        let property={configuration:this.state.config,offerType:this.state.offer,offerCost:this.state.offerCost,areaSqft:this.state.area,city:this.state.city,address:this.state.address,street:this.state.street,status:this.state.statusBit};
        console.log('property => ' + JSON.stringify(property));
        CreatePropertyService.createProperty(property).then(res =>{
            console.log('property ='+JSON.stringify(res.data))
            this.props.history.push("/showBrkoerProeprty");
        })
   
    }

    handleConfig = e =>{
        this.setState({
            config: e.target.value
        })
    }

    handleOffer = e =>{
        this.setState({
            offer:e.target.value
        })
    }
    
    handleOfferCost = e =>
    {
        this.setState({
            offerCost:e.target.value
        })
    }

    handleArea = e => {
        this.setState({
            area:e.target.value
        })
    }

    handleCity = e=>{
        this.setState({
            city:e.target.value
        })
    }
    
    handleAddress = e =>{
        this.setState({
            address:e.target.value
        })
    }

    handleStreet = e =>
    {
        this.setState({
            street:e.target.value
        })
    }
    
     handleStatus = e =>{
         this.setState({
             status:e.target.value
         })
         if(this.state.status==='available')
         {
            this.setState({
                statusBit:1
            })
         }
         else{
            this.setState({
                statusBit:0
            })
         }
     }

    render() {
        return (
            <div>
                <div class="container">
                    <img src={forms} width="500px" />
                </div>
                <div class='card'>
                    <div class='container'>
                        <div class="row align-items-center">
                            <h1>Enter Property Criteria</h1>

                            <form>
                                <div class="container text-center">
                                    <div>
                                        <label for="configuration">Configuration</label>
                                        <select name='configuration' id='configuration' value={this.state.config} onChange={this.handleConfig} style={{ marginLeft: '.5rem' }}>
                                            <option value='flat'>Flat</option>
                                            <option value='shop'>Shop</option>
                                            <option value='plot'>Plot</option>
                                        </select><br />

                                        <br />
                                    </div>

                                    <div>
                                        <label for='offerType'>Offer Type</label>
                                        <select name='offerType' id='offerType' value={this.state.offer} onChange={this.handleOffer} style={{ marginLeft: '.5rem' }}>
                                            <option value='sell'>Sell</option>
                                            <option value='rent'>Rent</option>
                                        </select><br />
                                        <br />
                                    </div>

                                    <div>
                                        <label for='offerCost'>Offer Cost</label>
                                        <input type='text' placeholder='Enter offer cost' value={this.state.offerCost} onChange={this.handleOfferCost} style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='area'>Area in sqft.</label>
                                        <input type='text' placeholder='Enter area' value={this.state.area} onChange={this.handleArea} style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='city'>City</label>
                                        <select name='city' id='city' value={this.state.city} onChange={this.handleCity} style={{ marginLeft: '.5rem' }}>
                                            <option value='ahmedabad'>Ahmedabad</option>
                                            <option value='bengaluru'>Bengaluru</option>
                                            <option value='Bhopal'>Bhopal</option>
                                            <option value='chennai'>Chennai</option>
                                            <option value='delhi'>Delhi</option>
                                            <option value='guwahati'>Guwahati</option>
                                            <option value='hyderabad'>Hyderabad</option>
                                            <option value='jaipur'>Jaipur</option>

                                            <option value='kanpur'>Kanpur</option>
                                            <option value='kochi'>Kochi</option>
                                            <option value='kolkata'>Kolkata</option>
                                            <option value='lucknow'>Lucknow</option>
                                            <option value='mumbai'>Mumbai</option>
                                            <option value='nagpur'>Nagpur</option>
                                            <option value='noida'>Noida</option>
                                            <option value='patna'>Patna</option>
                                            <option value='pune'>Pune</option>
                                            <option value='vizag'>Vizag</option>
                                        </select><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='address'>Address</label>
                                        <input type='text' placeholder='Enter Address' value={this.state.address} onChange={this.handleAddress} style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='street'>Street</label>
                                        <input type='text' placeholder='Enter street' value={this.state.street} onChange={this.handleStreet} style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='status'>Status</label>
                                        <select name='offerType' id='offerType' value={this.state.status} onChange={this.handleStatus} style={{ marginLeft: '.5rem' }}>
                                            <option value=''>Please select status</option>
                                            <option value='available'>Available</option>
                                            <option value='sold'>Sold</option>
                                        </select><br />
                                        <br />
                                    </div>
                                    <button class='btn btn-success' onClick={this.changeRegisterHandle}>REGISTER</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default CreatePropertyHandler 