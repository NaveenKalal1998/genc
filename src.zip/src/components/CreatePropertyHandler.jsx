import React, { Component } from 'react'
import forms from "../images/forms.png"
import { Card } from 'reactstrap';
class CreatePropertyHandler extends Component {
    render() {
        return (
            <div>
                <div class="container">
                    <img src={forms} width="500px" />
                </div>
                <div class='card'>
                    <div class='container'>
                        <div class="row align-items-center">
                            <h1>Enter Property Criteria</h1>

                            <form>
                                <div class="container text-center">
                                    <div>
                                        <label for="configuration">Configuration</label>
                                        <select name='configuration' id='configuration' style={{ marginLeft: '.5rem' }}>
                                            <option value='flat'>Flat</option>
                                            <option value='shop'>Shop</option>
                                            <option value='plot'>Plot</option>
                                        </select><br />

                                        <br />
                                    </div>

                                    <div>
                                        <label for='offerType'>Offer Type</label>
                                        <select name='offerType' id='offerType' style={{ marginLeft: '.5rem' }}>
                                            <option value='sell'>Sell</option>
                                            <option value='rent'>Rent</option>
                                        </select><br />
                                        <br />
                                    </div>

                                    <div>
                                        <label for='offerCost'>Offer Cost</label>
                                        <input type='text' placeholder='Enter offer cost' style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='area'>Area in sqft.</label>
                                        <input type='text' placeholder='Enter area' style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='city'>City</label>
                                        <select name='city' id='city' style={{ marginLeft: '.5rem' }}>
                                            <option value='ahmedabad'>Ahmedabad</option>
                                            <option value='bengaluru'>Bengaluru</option>
                                            <option value='Bhopal'>Bhopal</option>
                                            <option value='chennai'>Chennai</option>
                                            <option value='delhi'>Delhi</option>
                                            <option value='guwahati'>Guwahati</option>
                                            <option value='hyderabad'>Hyderabad</option>
                                            <option value='jaipur'>Jaipur</option>

                                            <option value='kanpur'>Kanpur</option>
                                            <option value='kochi'>Kochi</option>
                                            <option value='kolkata'>Kolkata</option>
                                            <option value='lucknow'>Lucknow</option>
                                            <option value='mumbai'>Mumbai</option>
                                            <option value='nagpur'>Nagpur</option>
                                            <option value='noida'>Noida</option>
                                            <option value='patna'>Patna</option>
                                            <option value='pune'>Pune</option>
                                            <option value='vizag'>Vizag</option>
                                        </select><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='address'>Address</label>
                                        <input type='text' placeholder='Enter Address' style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='street'>Street</label>
                                        <input type='text' placeholder='Enter street' style={{ marginLeft: '.5rem' }} required /><br />
                                        <br />
                                    </div>
                                    <div>
                                        <label for='status'>Status</label>
                                        <select name='offerType' id='offerType' style={{ marginLeft: '.5rem' }}>
                                            <option value=''>Please select status</option>
                                            <option value='available'>Available</option>
                                            <option value='sold'>Sold</option>
                                        </select><br />
                                        <br />
                                    </div>
                                    <button class='btn btn-success' >REGISTER</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default CreatePropertyHandler 