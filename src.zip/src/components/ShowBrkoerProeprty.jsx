import React, { Component } from 'react'

 class ShowBrkoerProeprty extends Component {
  render() {
    return (
      <div>
        <h1>Successfully Property Created</h1>
      </div>
    )
  }
}
export default ShowBrkoerProeprty