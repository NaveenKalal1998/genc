import React, { Component } from 'react'
import Header from './Header';
import Footer from './Footer';

class CustomerPage extends Component {
  render() {
    return (
      <div>
        <Header/><br/><br/><br/>
        <header>
        <nav class="navbar  navbar-expand-lg navbar-light bg-success">
        <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link" href="../search">Search Properties</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../customerListProp">List of Properties</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../customerMyProp">My Properties</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../customerUpdate">Update my details</a>
                  </li>
                </ul>
              </div>
        </div>
        </nav>
        </header>
      
      </div>
    )
  }
}
export default CustomerPage;