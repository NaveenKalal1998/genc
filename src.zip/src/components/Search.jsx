import React, { Component } from 'react';
import { Card } from 'reactstrap';
import property_search from "../images/property_search.png";
import CustomerPage from './CustomerPage';
import Header from './Header';
import SearchPropertyByCriteria from '../services/SearchPropertyByCriteria';
import axios from 'axios'
import Search1 from './Search1';
class Search extends Component {

  constructor(props) {
    super(props)

    this.state = {
      config: 'flat',
      offer: 'sell',
      city: 'Ahmedabad',
      minCost: '',
      maxCost: '',

      property: []
    }
    this.criteriaHandler = this.criteriaHandler.bind(this)
    this.handleConfig = this.handleConfig.bind(this)
    this.handleOffer = this.handleOffer.bind(this)
    this.handleCity = this.handleCity.bind(this)
    this.handleMincost = this.handleMincost.bind(this)
    this.handleMaxcost = this.handleMaxcost.bind(this)
    this.changeHandlerSerach = this.changeHandlerSerach.bind(this)
  }
  criteriaHandler = (e) => {

  }
  changeHandlerSerach = (e) => {
    e.preventDefault();
    let criterias = { config: this.state.config, offer: this.state.offer, city: this.state.city, minCost: this.state.minCost, maxCost: this.state.maxCost };
    console.log('criterias => ' + JSON.stringify(criterias));
    SearchPropertyByCriteria.searchProperty(criterias).then(res => {
      this.setState({ property: res.data });

      console.log(res.data)
      console.log('properties => ' + JSON.stringify(res.data))
      //this.props.history.push("/signin");
      //console.log(res.data.map(a => a.city))
      //res.data.map(a =><h1> a.city</h1>)

     //this.props.history.push("/search1");
    });
    // console.warn(this.state.name,this.state.email,this.state.password,this.state.mobile,this.state.role,this.state.city)

  }

  handleConfig = e => {
    this.setState({
      config: e.target.value
    })
  }

  handleOffer = e => {
    this.setState({
      offer: e.target.value
    })
  }

  handleCity = e => {
    this.setState({
      city: e.target.value
    })
  }

  handleMincost = e => {
    this.setState({
      minCost: e.target.value
    })
  }

  handleMaxcost = e => {
    this.setState({
      maxCost: e.target.value
    })
  }
  render() 
  {
    return (
      <div>
        <Header /><br /><br /><br />
        <CustomerPage />
        <div class='card'>
          <div class='container'>
            <div class="row align-items-center">
              <img src={property_search} width="300px" height="500px"></img>
            </div>
            <div class="row align-items-center">
              <h1>Enter Property Criteria</h1>

              <form onSubmit={this.criteriaHandler}>
                <div class="container text-center">
                  <div>
                    <label for="configuration">Configuration</label>
                    <select name='configuration' id='configuration' value={this.state.config} onChange={this.handleConfig} style={{ marginLeft: '.5rem' }}>
                      <option value='flat'>Flat</option>
                      <option value='shop'>Shop</option>
                      <option value='plot'>Plot</option>
                    </select><br />

                    <br />

                  </div>
                  <div>
                    <label for='offerType'>Offer Type</label>
                    <select name='offerType' id='offerType' value={this.state.offer} onChange={this.handleOffer} style={{ marginLeft: '.5rem' }}>
                      <option value='sell'>Sell</option>
                      <option value='rent'>Rent</option>
                    </select><br />
                    <br />
                  </div>
                  <div>
                    <label for='city'>City</label>
                    <select name='city' id='city' value={this.state.city} onChange={this.handleCity} style={{ marginLeft: '.5rem' }}>
                      <option value='ahmedabad'>Ahmedabad</option>
                      <option value='bengaluru'>Bengaluru</option>
                      <option value='Bhopal'>Bhopal</option>
                      <option value='chennai'>Chennai</option>
                      <option value='delhi'>Delhi</option>
                      <option value='guwahati'>Guwahati</option>
                      <option value='hyderabad'>Hyderabad</option>
                      <option value='jaipur'>Jaipur</option>

                      <option value='kanpur'>Kanpur</option>
                      <option value='kochi'>Kochi</option>
                      <option value='kolkata'>Kolkata</option>
                      <option value='lucknow'>Lucknow</option>
                      <option value='mumbai'>Mumbai</option>
                      <option value='nagpur'>Nagpur</option>
                      <option value='noida'>Noida</option>
                      <option value='patna'>Patna</option>
                      <option value='pune'>Pune</option>
                      <option value='vizag'>Vizag</option>
                    </select><br />
                    <br />
                  </div>
                  <div>
                    <label for='minimumCost'>Minimum Cost</label>
                    <input type='text' placeholder='Enter minimum cost' value={this.state.minCost} onChange={this.handleMincost} style={{ marginLeft: '.5rem' }} required /><br />
                    <br />
                    <div>
                      <label for='maximumCost'>Maximum Cost</label>
                      <input type='text' placeholder='Enter maximum cost' value={this.state.maxCost} onChange={this.handleMaxcost} style={{ marginLeft: '.5rem' }} required /><br />
                      <br />

                      {/* <label for="role"> Choose a role</label>
                      <select name='role' id='role' style={{ marginLeft: '.5rem' }}>
                        <option value='customer'>Customer</option>
                        <option value='broker'>Broker</option>
                      </select><br /> */}
                    </div>
                    <br />
                    <button class='btn btn-success' onClick={this.changeHandlerSerach} >Search</button>
                  </div>

                </div>
              </form>
            
              </div>
              
            </div>
            <div className="row">
                <table className="table table-striped table-bordered">

                  <thead>
                    <tr>
                      <th> Configuration</th>
                      <th> OfferType</th>
                      <th> OfferCost</th>
                      <th> Area Sqft</th>
                      <th> City</th>
                      <th> Address</th>
                      <th> Street</th>
                      <th> Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {
                      this.state.property.map(
                        pr =>
                          <tr key={pr.propId}>
                            <td> {pr.configuration} </td>
                            <td> {pr.offerType}</td>
                            <td> {pr.offerCost}</td>
                            <td> {pr.areaSqft}</td>
                            <td> {pr.city}</td>
                            <td> {pr.address}</td>
                            <td> {pr.street}</td>
                            <td> {pr.status}</td>
                          </tr>
                      )}
                  </tbody>
                </table>
                </div>
          </div>
        </div>
        )
  }
}
        
        export default Search;