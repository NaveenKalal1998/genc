import React, { Component } from 'react'
import EstateLogo from '../images/EstateLogo.png'

class Header extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       
    }
  }
  
  render() {
    return (
      <div>
        <header>
          <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">
                <img src={EstateLogo} alt="" width="50" height="44" class="d-inline-block align-text-top" />

              </a>
              <span class="navbar-brand mb-0 h1">EstateAgency</span>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../home">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../about">About</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../properties">Properties</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../developers">Developers</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../contact">Contact</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../login">Login</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../signin">Signin</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../login">Logout</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </header>
      </div>
    )
  }
}
export default Header
