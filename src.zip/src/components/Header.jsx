import React, { Component } from 'react'
import EstateLogo from '../images/EstateLogo.png'
import { withRouters } from "react-router";
class Header extends Component {
  constructor(props) {
    super(props)
  
    this.state = {
       
    }
    this.logout=this.logout.bind(this);
  }
  logout=()=>{
    localStorage.removeItem('loggedIn')
    window.location.reload();
  }
  render() {
    const isLoggedIn = localStorage.getItem('loggedIn');
    console.log('Loggin',isLoggedIn)
    return (
      <div>
        <header>
          <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">
                <img src={EstateLogo} alt="" width="50" height="44" class="d-inline-block align-text-top" />

              </a>
              <span class="navbar-brand mb-0 h1">EstateAgency</span>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="../home" style={{fontWeight:600}}>Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../about" style={{fontWeight:600}}>About</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../properties" style={{fontWeight:600}}>Properties</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../developers" style={{fontWeight:600}}>Developers</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../contact" style={{fontWeight:600}}>Contact</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="../signin" style={{fontWeight:600}}>Signin</a>
                  </li>
                  <div>
                  { isLoggedIn?(
                  <li class="nav-item">
                  <a class="nav-link" style={{fontWeight:600}} onClick={this.logout} href='javascript:void(0)'>Logout</a>
                </li>):('')
                  }
                  </div>

                </ul>
              </div>
            </div>
          </nav>
        </header>
      </div>
    )
  }
}
export default Header
