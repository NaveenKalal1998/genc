import React, { Component } from 'react'

export default class Search1 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         
      }
    }
    
  render() {
    return (
      <div>
        Hi
        
      </div>
    )
  }
}
