import React, { Component } from 'react'

class Footer extends Component {
  render() {
    return (
      <div>
        <footer>
          <div class='container'>
            <div class="row align-items-center">
              <div class="col">
                <h1 class="text-start">EstateAgency</h1>
                <p class="text-start">Launched in 2021, EstateAgency is India's No.1 online Property marketplace to buy, sell, and rent residential and commercial properties. Adjudged as the most preferred real estate portal in India by various independent surveys.<br /> <br />Email : GencRealEstate@gmail.com <br /><br />Phone : +91 9999999999</p>
              </div>
              <div class="col">
                <h1 class="text-start">The Company</h1>
                <p class="text-start"><ul>
                  <li>Site Map</li>
                  <li>Legal</li>
                  <li>Agent Admin</li>
                  <li>Careers</li>
                  <li>Affiliate</li>
                  <li>Privacy Policy</li>
                </ul>
                </p>
              </div>
              <div class="col">
                <h1 class="text-start">Our Office Locations</h1>
                <p class="text-start"><ul>
                  <li>Bengaluru</li>
                  <li>Hyderabad</li>
                  <li>Chennai</li>
                  <li>Mumbai</li>
                  <li>Pune</li>
                  <li>Goa</li>
                </ul>
                </p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    )
  }
}

export default Footer